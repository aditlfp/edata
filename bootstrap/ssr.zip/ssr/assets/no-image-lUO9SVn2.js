const NoImage = "/build/assets/no-image-Cvya9Jub.jpg";
export {
  NoImage as N
};
