import { jsx } from "react/jsx-runtime";
import { A as AdminLayout } from "./AdminLayout-CvSKtEe9.js";
function Authenticated({ user, header, children }) {
  return /* @__PURE__ */ jsx(AdminLayout, { children });
}
export {
  Authenticated as A
};
