const Header = "/build/assets/header-Ddwo-g_a.png";
export {
  Header as H
};
